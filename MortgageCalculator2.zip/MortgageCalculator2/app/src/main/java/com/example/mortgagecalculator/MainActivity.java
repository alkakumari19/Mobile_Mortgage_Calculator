package com.example.mortgagecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    private EditText EnterMortgage, EnterInterest, EnterAmount;
    private TextView Answer ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Linking the UI to the code, takes the ID and turns it into EditText type such.
        EnterMortgage = (EditText)findViewById(R.id.EnterMortgage);
        EnterInterest = (EditText)findViewById(R.id.EnterInterest);
        EnterAmount = (EditText)findViewById(R.id.EnterAmount);
        Answer = (TextView)findViewById(R.id.Answer);

    }

    public void CalculateEMI (View clickedButton){

        //Getting the input from the Ui and converting it into numbers
        //EnterMortgage.getText().toString() , it takes the text from the user and converts it to a string,
        // which then converts it into a number and stores it into the number type variables EMortgage.
        double EMortgage = Double.parseDouble(EnterMortgage.getText().toString());
        double EInterest = Double.parseDouble(EnterInterest.getText().toString());
        int EAmount = Integer.parseInt(EnterAmount.getText().toString());

        //convert interest into decimal then /12 to get monthly interest
        double InterestRate = ((EInterest/100)/12);

        // Takes the year value (Amount) and converting it into months
        int NumberOfMonths = EAmount*12;

        // Formula to Calculating EMI

        double monthlyPayment= (EMortgage* InterestRate* Math.pow( 1 + InterestRate, NumberOfMonths))/ (Math.pow( 1 + InterestRate, NumberOfMonths)-1);
        //Sets the text on the UI
        Answer.setText(new DecimalFormat("##.##").format(monthlyPayment));







    }


    }
